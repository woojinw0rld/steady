# Do it! 자바스크립트 입문
"Do it! 자바스크립트 입문" 에서 사용하는 실습 파일을 제공하고 있습니다. (2021년 11월)

![](https://user-images.githubusercontent.com/5915404/159109156-af96e9fe-ed49-4d84-a022-6c70ceb674a7.jpeg)
