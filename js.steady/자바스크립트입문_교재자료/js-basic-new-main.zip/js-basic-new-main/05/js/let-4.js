var x = 100;

test();

function test() { 			
	document.write("x is " + x + ", y is " + y);
  let y = 200;
}