// let sum = function(a, b) {
//   return a + b;
// }

// let sum = (a, b) => { return a + b }

let sum = (a, b) => a + b;
        
document.write("두 수의 합 : " + sum(10, 20));