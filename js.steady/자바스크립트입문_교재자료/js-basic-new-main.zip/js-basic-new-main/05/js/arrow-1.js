// const hi = function() {
//   return "안녕하세요?";
// }
        
// const hi = () => {return "안녕하세요?"};

const hi = () => "안녕하세요?";
        
alert(hi());