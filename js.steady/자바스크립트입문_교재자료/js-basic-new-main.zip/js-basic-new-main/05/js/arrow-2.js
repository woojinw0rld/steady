// let hi = function(user) {
//    document.write (user + "님, 안녕하세요?");
// }
        
// let hi = (user) => { document.write (user + "님, 안녕하세요?"); }
        
let hi = user => { document.write (user + "님, 안녕하세요?"); }
        
 hi("경희");